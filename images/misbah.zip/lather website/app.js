
// OUR PRODUCT PAGE

function Display(event) { 
let displayimg = document.getElementById('displayimg');
let productsCardContainer = document.getElementById('productsCardContainer');
    let getImage = event.src;
    console.log(getImage);
    let imagetag = document.createElement('img');
    imagetag.src = getImage;
    displayimg.appendChild(imagetag);
    displayimg.style.display = "block";
    displayimg.style.overflowY = "hidden";
    productsCardContainer.style.filter = "blur(5px)";

        let x = document.getElementById('X');
        x.addEventListener('click', ()=>{
            displayimg.style.display = "none";
            productsCardContainer.style.filter = "none";
             displayimg.innerText= "";
        })
       
}




